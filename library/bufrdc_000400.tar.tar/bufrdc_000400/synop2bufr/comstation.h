C Copyright 1981-2012 ECMWF. 
C
C This software is licensed under the terms of the GNU Lesser 
C General Public License Version 3 which can be obtained at 
C http://www.gnu.org/licenses/lgpl.html.  
C 
C In applying this licence, ECMWF does not waive the privileges 
C and immunities granted to it by virtue of its status as an 
C intergovernmental organisation nor does it submit to any
C jurisdiction. 
C 
C     'COMSTATION' CONTAINS WMO station list
C
      COMMON / COMSTATION / irgcoun(13000),istid(13000),
     C                  rlatid(13000),
     C                  rlongid(13000),isthp(13000),istha(13000),
     C                  ipcode(13000),csp00(13000),csp03(13000),
     C                  csp06(13000),csp09(13000),csp12(13000),
     C                  csp15(13000),csp18(13000),csp21(13000),
     C                  cuat00(13000),cuat06(13000),cuat12(13000),
     C                  cuat18(13000),cstation(13000),RH_tem(13000),
     C                  RH_vis(13000),RH_prec(13000),RH_wind(13000),NST
C
